// 拉钩网深度调试脚本
// 请在拉钩网页面按F12打开控制台，粘贴此脚本并回车运行

(function() {
  console.log('%c=== 拉钩网深度调试 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  
  // 1. 检测平台
  const host = window.location.hostname;
  console.log('当前域名:', host);
  console.log('是否拉钩网:', host.includes('lagou.com') ? '✅ 是' : '❌ 否');
  console.log('当前URL:', window.location.href);
  
  // 2. 测试岗位卡片选择器
  console.log('\n%c【测试岗位卡片选择器】', 'color: #ff9800; font-weight: bold;');
  
  const testSelectors = [
    '.item__10RTO',
    '[class*="item__"]',
    '.position_list_item',
    '.list_item_box',
    '[class*="position"]',
    'div[data-positionid]'
  ];
  
  let foundSelector = null;
  let foundCards = [];
  
  for (const selector of testSelectors) {
    const cards = document.querySelectorAll(selector);
    console.log(`选择器 "${selector}": 找到 ${cards.length} 个元素`);
    if (cards.length > 0 && !foundSelector) {
      foundSelector = selector;
      foundCards = Array.from(cards);
    }
  }
  
  if (!foundSelector) {
    console.error('%c❌ 未找到任何岗位卡片！', 'color: red; font-size: 14px;');
    console.log('请检查页面是否已加载完成，或手动查找岗位卡片的class名');
    return;
  }
  
  console.log(`%c✅ 使用选择器: ${foundSelector}`, 'color: green; font-size: 14px;');
  
  // 3. 详细检查第一个岗位卡片
  console.log('\n%c【分析第一个岗位卡片】', 'color: #ff9800; font-weight: bold;');
  const firstCard = foundCards[0];
  
  // 打印整个卡片的HTML结构（前500字符）
  console.log('卡片HTML结构（前500字符）:');
  console.log(firstCard.outerHTML.substring(0, 500));
  
  // 4. 测试各个选择器
  console.log('\n%c【测试各信息选择器】', 'color: #ff9800; font-weight: bold;');
  
  // 岗位名称
  const nameTests = [
    '.p-top__1F7CL a',
    '[class*="p-top"] a',
    'a[id="openWinPostion"]',
    '.position a',
    '[class*="position"] a'
  ];
  
  for (const test of nameTests) {
    const el = firstCard.querySelector(test);
    console.log(`岗位名选择器 "${test}": ${el ? '✅ ' + el.textContent.trim().substring(0, 30) : '❌ 未找到'}`);
  }
  
  // 薪资
  const salaryTests = [
    '.money__3Lkgq',
    '[class*="money"]',
    '.salary',
    '[class*="salary"]'
  ];
  
  for (const test of salaryTests) {
    const el = firstCard.querySelector(test);
    console.log(`薪资选择器 "${test}": ${el ? '✅ ' + el.textContent.trim() : '❌ 未找到'}`);
  }
  
  // 公司名称
  const companyTests = [
    '.company-name__2-SjF a',
    '[class*="company-name"] a',
    '.company a',
    '[class*="company"] a'
  ];
  
  for (const test of companyTests) {
    const el = firstCard.querySelector(test);
    console.log(`公司选择器 "${test}": ${el ? '✅ ' + el.textContent.trim() : '❌ 未找到'}`);
  }
  
  // 5. 检查插件是否已注入
  console.log('\n%c【检查插件注入状态】', 'color: #ff9800; font-weight: bold;');
  
  // 检查分析容器
  const analyzeContainer = firstCard.querySelector('.jh-analysis-container');
  console.log('分析容器:', analyzeContainer ? '✅ 已注入' : '❌ 未注入');
  
  // 检查分析按钮
  const analyzeBtn = firstCard.querySelector('.jh-analyze-btn');
  console.log('分析按钮:', analyzeBtn ? '✅ 已注入' : '❌ 未注入');
  
  // 检查页面上的所有分析按钮
  const allBtns = document.querySelectorAll('.jh-analyze-btn');
  console.log(`页面上的分析按钮总数: ${allBtns.length}`);
  
  // 6. 检查content script是否加载
  console.log('\n%c【检查Content Script加载状态】', 'color: #ff9800; font-weight: bold;');
  
  // 尝试检测我们的函数是否存在于全局作用域
  const hasContentScript = window.jhDebugMode !== undefined || 
                           document.querySelector('.jh-analysis-container') !== null;
  console.log('Content Script状态:', hasContentScript ? '✅ 已加载' : '❌ 未加载');
  
  // 7. 如果未注入，尝试手动注入
  if (!analyzeContainer) {
    console.log('\n%c【尝试手动注入】', 'color: #ff9800; font-weight: bold;');
    
    // 手动注入测试
    const container = document.createElement('div');
    container.className = 'jh-analysis-container';
    container.innerHTML = `
      <button class="jh-analyze-btn" style="
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 20px;
        cursor: pointer;
        font-size: 12px;
        box-shadow: 0 2px 8px rgba(102, 126, 234, 0.4);
        transition: all 0.3s ease;
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 9999;
      ">🔍 测试分析</button>
    `;
    
    firstCard.style.position = 'relative';
    firstCard.appendChild(container);
    
    console.log('%c✅ 已手动注入测试按钮到第一个岗位卡片', 'color: green;');
    console.log('请查看页面右上角是否出现"测试分析"按钮');
  }
  
  // 8. 总结和建议
  console.log('\n%c=== 调试总结 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  
  if (foundSelector && foundCards.length > 0) {
    console.log('✅ 岗位卡片检测正常');
    console.log(`✅ 共找到 ${foundCards.length} 个岗位卡片`);
    
    if (!analyzeContainer) {
      console.error('❌ 插件未正确注入到岗位卡片');
      console.log('\n可能的原因:');
      console.log('1. Content Script未加载 - 请检查插件是否已安装并启用');
      console.log('2. 页面未刷新 - 请刷新拉钩网页面');
      console.log('3. 权限问题 - 检查插件是否有访问拉钩网的权限');
      console.log('4. 选择器不匹配 - 当前页面的DOM结构可能与预期不同');
      console.log('\n建议操作:');
      console.log('→ 刷新页面后重试');
      console.log('→ 检查插件管理页面，确认插件已启用');
      console.log('→ 重新加载插件');
    } else {
      console.log('✅ 插件已正确注入');
      console.log('如果仍无法使用，请检查浏览器控制台是否有错误信息');
    }
  }
  
  console.log('\n%c如有问题，请将此调试信息截图反馈', 'color: #999; font-style: italic;');
})();