// 猎聘网页面结构分析脚本
// 请在猎聘网页面按F12打开控制台，粘贴此脚本并回车运行

(function() {
  console.log('%c=== 猎聘网页面结构分析 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  
  // 1. 检测平台
  const host = window.location.hostname;
  console.log('当前域名:', host);
  console.log('是否猎聘网:', host.includes('liepin.com') ? '✅ 是' : '❌ 否');
  console.log('当前URL:', window.location.href);
  
  // 2. 测试常见的岗位卡片选择器
  console.log('\n%c【测试岗位卡片选择器】', 'color: #ff9800; font-weight: bold;');
  
  const testSelectors = [
    // 猎聘网常见选择器
    '.sojob-item',
    '.job-list-item',
    '.list-item',
    '[class*="job-item"]',
    '[class*="sojob"]',
    'div[data-job-id]',
    'li[data-job-id]',
    '.job-card',
    '[class*="card-item"]',
    'article'
  ];
  
  let foundSelector = null;
  let foundCards = [];
  
  for (const selector of testSelectors) {
    const cards = document.querySelectorAll(selector);
    console.log(`选择器 "${selector}": 找到 ${cards.length} 个元素`);
    if (cards.length > 0 && !foundSelector) {
      foundSelector = selector;
      foundCards = Array.from(cards);
    }
  }
  
  if (!foundSelector) {
    console.error('%c❌ 未找到岗位卡片！尝试通用方法...', 'color: red; font-size: 14px;');
    
    // 尝试查找包含"薪资"关键词的列表项
    const allDivs = document.querySelectorAll('div, li, article');
    for (const div of allDivs) {
      const text = div.textContent;
      if (text && text.includes('万') && (text.includes('本科') || text.includes('硕士') || text.includes('经验'))) {
        console.log('可能找到岗位卡片:', div.className || div.tagName);
        if (!foundCards.includes(div) && div.offsetHeight > 50 && div.offsetHeight < 300) {
          foundCards.push(div);
          if (!foundSelector) {
            foundSelector = div.className ? '.' + div.className.split(' ')[0] : div.tagName;
            console.log('使用选择器:', foundSelector);
          }
        }
      }
    }
    
    if (foundCards.length === 0) {
      console.error('仍未找到岗位卡片，请手动检查');
      return;
    }
  }
  
  console.log(`%c✅ 使用选择器: ${foundSelector}`, 'color: green; font-size: 14px;');
  console.log(`找到 ${foundCards.length} 个岗位卡片`);
  
  // 3. 分析第一个岗位卡片的详细结构
  console.log('\n%c【分析第一个岗位卡片】', 'color: #ff9800; font-weight: bold;');
  const firstCard = foundCards[0];
  
  // 打印整个卡片的HTML结构
  console.log('\n完整HTML结构:');
  console.log(firstCard.outerHTML);
  
  // 4. 提取关键信息
  console.log('\n%c【尝试提取岗位信息】', 'color: #ff9800; font-weight: bold;');
  
  // 岗位名称
  const titleSelectors = [
    'a[title]',
    '.job-title',
    '[class*="title"]',
    '[class*="job-name"]',
    'h3',
    'h4',
    'a'
  ];
  
  for (const selector of titleSelectors) {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.trim().length > 0 && el.textContent.trim().length < 50) {
      console.log(`岗位名选择器 "${selector}": ✅ ${el.textContent.trim()}`);
    }
  }
  
  // 薪资
  const salarySelectors = [
    '.text-warning',
    '.salary',
    '[class*="salary"]',
    '[class*="money"]',
    '[class*="income"]',
    'span'
  ];
  
  for (const selector of salarySelectors) {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.includes('万')) {
      console.log(`薪资选择器 "${selector}": ✅ ${el.textContent.trim()}`);
    }
  }
  
  // 公司名称
  const companySelectors = [
    '.company-name',
    '[class*="company"]',
    'a[href*="company"]',
    'p'
  ];
  
  for (const selector of companySelectors) {
    const els = firstCard.querySelectorAll(selector);
    els.forEach(el => {
      const text = el.textContent.trim();
      if (text.length > 2 && text.length < 30 && !text.includes('万') && !text.includes('本科')) {
        console.log(`公司选择器 "${selector}": 可能是 ✅ ${text}`);
      }
    });
  }
  
  // 地点
  const locationSelectors = [
    '[class*="area"]',
    '[class*="city"]',
    '[class*="location"]',
    'span'
  ];
  
  for (const selector of locationSelectors) {
    const els = firstCard.querySelectorAll(selector);
    els.forEach(el => {
      const text = el.textContent.trim();
      if (text.length > 1 && text.length < 20 && /[\u4e00-\u9fa5]/.test(text) && !text.includes('万')) {
        console.log(`地点选择器 "${selector}": 可能是 ✅ ${text}`);
      }
    });
  }
  
  // 5. 查找所有链接（通常包含重要信息）
  console.log('\n%c【卡片中的所有链接】', 'color: #ff9800; font-weight: bold;');
  const links = firstCard.querySelectorAll('a');
  links.forEach((link, index) => {
    const text = link.textContent.trim().substring(0, 30);
    const href = link.href.substring(0, 50);
    console.log(`链接${index + 1}: "${text}" -> ${href}`);
  });
  
  // 6. 分析class名称规律
  console.log('\n%c【分析class名称】', 'color: #ff9800; font-weight: bold;');
  const allElements = firstCard.querySelectorAll('*');
  const classMap = {};
  
  allElements.forEach(el => {
    if (el.className && typeof el.className === 'string') {
      const classes = el.className.split(' ').filter(c => c.length > 0);
      classes.forEach(cls => {
        if (!classMap[cls]) {
          classMap[cls] = [];
        }
        const text = el.textContent.trim().substring(0, 20);
        if (text) {
          classMap[cls].push(text);
        }
      });
    }
  });
  
  // 只显示包含关键信息的class
  console.log('包含"job"、"title"、"salary"、"company"的class:');
  Object.keys(classMap).forEach(cls => {
    if (cls.includes('job') || cls.includes('title') || cls.includes('salary') || 
        cls.includes('company') || cls.includes('name') || cls.includes('money')) {
      console.log(`  .${cls}:`, classMap[cls].slice(0, 2).join(', '));
    }
  });
  
  // 7. 总结
  console.log('\n%c=== 分析总结 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  console.log('请将以上输出截图或复制给开发者，以便编写适配代码');
  console.log('\n推荐选择器:');
  console.log(`  岗位卡片: ${foundSelector}`);
  console.log(`  岗位数量: ${foundCards.length}`);
})();