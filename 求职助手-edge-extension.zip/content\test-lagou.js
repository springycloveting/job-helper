// 拉钩网适配测试脚本
// 在拉钩网页面的控制台中运行此脚本，验证岗位信息提取是否正确

(function testLagouAdaptation() {
  console.log('=== 拉钩网适配测试开始 ===');
  
  // 测试1：检测岗位卡片选择器
  const selectors = [
    '.item__10RTO',
    '[class*="item__"]',
    '.position_list_item'
  ];
  
  let foundSelector = null;
  let foundCards = [];
  
  for (const selector of selectors) {
    const cards = document.querySelectorAll(selector);
    if (cards.length > 0) {
      foundSelector = selector;
      foundCards = Array.from(cards);
      console.log(`✅ 找到岗位卡片选择器: ${selector}, 共 ${cards.length} 个`);
      break;
    }
  }
  
  if (!foundSelector) {
    console.error('❌ 未找到岗位卡片，请检查选择器');
    return;
  }
  
  // 测试2：提取第一个岗位的信息
  const firstCard = foundCards[0];
  console.log('\n--- 测试提取第一个岗位信息 ---');
  
  // 岗位名称
  const nameEl = firstCard.querySelector('.p-top__1F7CL a, [class*="p-top"] a');
  const title = nameEl ? nameEl.textContent.trim() : '';
  console.log('岗位名称:', title || '❌ 未提取到');
  
  // 薪资
  const salaryEl = firstCard.querySelector('.money__3Lkgq, [class*="money"]');
  const salary = salaryEl ? salaryEl.textContent.trim() : '';
  console.log('薪资:', salary || '❌ 未提取到');
  
  // 公司名称
  const companyEl = firstCard.querySelector('.company-name__2-SjF a, [class*="company-name"] a');
  const company = companyEl ? companyEl.textContent.trim() : '';
  console.log('公司:', company || '❌ 未提取到');
  
  // 地点
  const locationMatch = title.match(/\[(.+?)\]/);
  const location = locationMatch ? locationMatch[1] : '';
  console.log('地点:', location || '❌ 未提取到');
  
  // 标签
  const tagsEl = firstCard.querySelector('.p-bom__JlNur, [class*="p-bom"]');
  const tags = tagsEl ? tagsEl.textContent.trim() : '';
  console.log('标签:', tags || '❌ 未提取到');
  
  // 行业
  const industryEl = firstCard.querySelector('.industry__1HBkr, [class*="industry"]');
  const industry = industryEl ? industryEl.textContent.trim() : '';
  console.log('行业:', industry || '❌ 未提取到');
  
  // 测试3：检查分析按钮是否注入
  const analyzeBtn = firstCard.querySelector('.jh-analyze-btn');
  if (analyzeBtn) {
    console.log('\n✅ 分析按钮已注入');
  } else {
    console.log('\n❌ 分析按钮未注入');
  }
  
  // 汇总
  console.log('\n=== 测试结果汇总 ===');
  const allExtracted = title && salary && company;
  if (allExtracted) {
    console.log('✅ 所有关键信息提取成功！');
    console.log('摘要:', [title.split('[')[0], salary, company, industry, location].filter(Boolean).join(' | '));
  } else {
    console.log('⚠️ 部分信息提取失败，请检查选择器');
  }
  
  console.log('\n提示: 如果测试通过但插件仍无法使用，请刷新拉钩网页面重试。');
})();