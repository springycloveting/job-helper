// 猎聘网页面结构分析脚本 V2
// 专门针对猎聘网的搜索结果列表页

(function() {
  console.log('%c=== 猎聘网页面结构分析 V2 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  
  // 1. 检测平台
  const host = window.location.hostname;
  console.log('当前域名:', host);
  console.log('当前URL:', window.location.href);
  
  // 2. 查找岗位列表容器
  console.log('\n%c【查找岗位列表容器】', 'color: #ff9800; font-weight: bold;');
  
  const containerSelectors = [
    '.job-list-box',
    '.sojob-list',
    '.list-ul',
    '[class*="job-list"]',
    '.search-result',
    '[class*="search-result"]',
    'ul.job-list',
    '.jobsearch-result'
  ];
  
  let listContainer = null;
  for (const selector of containerSelectors) {
    const container = document.querySelector(selector);
    if (container) {
      console.log(`✅ 找到列表容器: ${selector}`);
      listContainer = container;
      break;
    }
  }
  
  if (!listContainer) {
    console.log('未找到明确的列表容器，尝试从body直接查找');
    listContainer = document.body;
  }
  
  // 3. 在容器内查找岗位卡片
  console.log('\n%c【查找岗位卡片】', 'color: #ff9800; font-weight: bold;');
  
  const cardSelectors = [
    '.job-card-left-box',
    '.sojob-item-main',
    '.job-info',
    '[class*="job-card"]',
    'li[data-job-id]',
    'div[data-job-id]',
    '.list-item',
    'li'
  ];
  
  let foundCards = [];
  let foundSelector = null;
  
  for (const selector of cardSelectors) {
    const cards = listContainer.querySelectorAll(selector);
    if (cards.length > 5) { // 至少找到5个才算有效
      foundSelector = selector;
      foundCards = Array.from(cards);
      console.log(`✅ 使用选择器: ${selector}, 找到 ${cards.length} 个岗位卡片`);
      break;
    } else if (cards.length > 0) {
      console.log(`选择器 "${selector}": 找到 ${cards.length} 个元素（太少，继续查找）`);
    }
  }
  
  if (!foundSelector || foundCards.length === 0) {
    console.error('%c❌ 未找到岗位卡片！', 'color: red; font-size: 14px;');
    console.log('\n%c【尝试遍历所有元素】', 'color: #ff9800; font-weight: bold;');
    
    // 遍历所有div和li，查找包含薪资信息的元素
    const allElements = document.querySelectorAll('div, li');
    const potentialCards = [];
    
    allElements.forEach(el => {
      const text = el.textContent || '';
      // 猎聘网薪资通常包含"万"或"k"
      if (text.includes('万') || text.includes('k') || text.includes('K')) {
        const hasSalary = text.match(/\d+[-~]\d+[万kK]/);
        const hasJob = text.includes('经理') || text.includes('工程师') || text.includes('专员') || text.includes('总监');
        
        if (hasSalary && hasJob) {
          potentialCards.push({
            element: el,
            className: el.className,
            text: text.substring(0, 100)
          });
        }
      }
    });
    
    console.log(`找到 ${potentialCards.length} 个潜在岗位卡片`);
    potentialCards.slice(0, 3).forEach((item, index) => {
      console.log(`\n潜在卡片 ${index + 1}:`);
      console.log('  class:', item.className);
      console.log('  文本预览:', item.text);
    });
    
    if (potentialCards.length > 0) {
      foundCards = potentialCards.map(p => p.element);
      foundSelector = potentialCards[0].className ? '.' + potentialCards[0].className.split(' ')[0] : 'div';
      console.log(`\n使用选择器: ${foundSelector}`);
    } else {
      return;
    }
  }
  
  // 4. 分析第一个岗位卡片
  console.log('\n%c【分析第一个岗位卡片】', 'color: #ff9800; font-weight: bold;');
  const firstCard = foundCards[0];
  
  // 打印前800字符的HTML
  console.log('\n卡片HTML结构（前800字符）:');
  console.log(firstCard.outerHTML.substring(0, 800));
  
  // 5. 提取关键信息
  console.log('\n%c【提取岗位信息】', 'color: #ff9800; font-weight: bold;');
  
  // 岗位名称
  console.log('\n岗位名称:');
  ['.job-title-box div[title]', '.job-title', '[class*="title"]', 'a[title]', 'h3', 'h4'].forEach(selector => {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.trim()) {
      console.log(`  "${selector}": ✅ ${el.textContent.trim().substring(0, 50)}`);
    }
  });
  
  // 薪资
  console.log('\n薪资:');
  ['.job-salary', '[class*="salary"]', '.text-warning'].forEach(selector => {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.trim()) {
      console.log(`  "${selector}": ✅ ${el.textContent.trim()}`);
    }
  });
  
  // 公司
  console.log('\n公司:');
  ['.company-name', '[class*="company-name"]'].forEach(selector => {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.trim()) {
      console.log(`  "${selector}": ✅ ${el.textContent.trim()}`);
    }
  });
  
  // 地点
  console.log('\n地点:');
  ['.job-dq-box span', '[class*="dq"]', '[class*="area"]'].forEach(selector => {
    const el = firstCard.querySelector(selector);
    if (el && el.textContent.trim() && !el.textContent.includes('【')) {
      console.log(`  "${selector}": ✅ ${el.textContent.trim()}`);
    }
  });
  
  console.log('\n%c=== 分析完成 ===', 'color: #00a0e9; font-size: 16px; font-weight: bold;');
  console.log('岗位卡片选择器:', foundSelector);
  console.log('岗位数量:', foundCards.length);
})();