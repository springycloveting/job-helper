// 临时调试脚本v2：更深入探测Boss直聘页面DOM结构
(function() {
  const results = [];
  
  // 1. 页面基本信息
  results.push('URL: ' + window.location.href);
  results.push('页面大小: ' + document.body.innerHTML.length + ' chars');
  results.push('body直接子元素: ' + document.body.children.length);
  
  // 2. body直接子元素结构
  results.push('\n=== body直接子元素 ===');
  Array.from(document.body.children).forEach((el, i) => {
    results.push(i + ': <' + el.tagName + ' id="' + (el.id||'') + '" class="' + (el.className||'').substring(0,80) + '"> children=' + el.children.length);
  });

  // 3. 搜索所有a标签，找包含job的链接
  results.push('\n=== 包含job/vacancy/hire的链接 ===');
  const jobLinks = Array.from(document.querySelectorAll('a')).filter(a => 
    a.href && (a.href.includes('job') || a.href.includes('vacancy') || a.href.includes('hire') || a.href.includes('zhaopin'))
  );
  results.push('数量: ' + jobLinks.length);
  jobLinks.slice(0, 3).forEach((a, i) => {
    results.push(i + ': href=' + a.href.substring(0, 80) + ' text=' + a.textContent.substring(0, 30).trim());
    let parent = a.parentElement;
    const chain = [];
    while (parent && chain.length < 6) {
      chain.push('<' + parent.tagName + ' class="' + (parent.className||'').substring(0, 60) + '">');
      parent = parent.parentElement;
    }
    results.push('  父级: ' + chain.join(' > '));
  });

  // 4. 查找包含"K"薪资文本的元素（如 "15-25K"）
  results.push('\n=== 包含K薪资文本的元素 ===');
  const allElements = document.querySelectorAll('*');
  let salaryCount = 0;
  for (let i = 0; i < allElements.length && salaryCount < 3; i++) {
    const el = allElements[i];
    if (el.children.length === 0 || el.children.length <= 2) {
      const text = el.textContent.trim();
      if (text && /^\d+[-~]\d+K/.test(text)) {
        salaryCount++;
        results.push(salaryCount + ': text="' + text.substring(0, 30) + '" tag=' + el.tagName + ' class="' + (el.className||'').substring(0, 60) + '"');
        let parent = el.parentElement;
        const chain = [];
        while (parent && chain.length < 6) {
          chain.push('<' + parent.tagName + ' class="' + (parent.className||'').substring(0, 60) + '">');
          parent = parent.parentElement;
        }
        results.push('  父级: ' + chain.join(' > '));
      }
    }
  }
  if (salaryCount === 0) results.push('未找到');

  // 5. 查找最可能的"列表容器"（子元素多且结构重复的元素）
  results.push('\n=== 子元素最多的容器 ===');
  let maxContainer = null;
  let maxCount = 0;
  document.querySelectorAll('div, ul, section').forEach(el => {
    if (el.children.length > maxCount && el.children.length < 200) {
      // 检查子元素是否有相似结构
      const classes = Array.from(el.children).map(c => c.className).filter(c => c);
      const uniqueClasses = new Set(classes);
      if (classes.length > 0 && uniqueClasses.size <= classes.length * 0.5) {
        maxCount = el.children.length;
        maxContainer = el;
      }
    }
  });
  if (maxContainer) {
    results.push('class="' + maxContainer.className.substring(0, 80) + '" children=' + maxContainer.children.length);
    Array.from(maxContainer.children).slice(0, 2).forEach((child, j) => {
      results.push('  子' + j + ': <' + child.tagName + ' class="' + (child.className||'').substring(0, 80) + '"> children=' + child.children.length);
      Array.from(child.children).slice(0, 4).forEach((gc, k) => {
        results.push('    孙' + k + ': <' + gc.tagName + ' class="' + (gc.className||'').substring(0, 80) + '"> text="' + gc.textContent.substring(0, 30).trim() + '"');
      });
    });
  } else {
    results.push('未找到');
  }

  // 6. 检查是否有iframe
  results.push('\n=== iframe ===');
  const iframes = document.querySelectorAll('iframe');
  results.push('数量: ' + iframes.length);
  iframes.forEach((f, i) => {
    results.push(i + ': src=' + (f.src||'').substring(0, 80));
  });

  // 7. 查找shadow DOM
  results.push('\n=== Shadow DOM ===');
  let shadowCount = 0;
  document.querySelectorAll('*').forEach(el => {
    if (el.shadowRoot) {
      shadowCount++;
      results.push(shadowCount + ': <' + el.tagName + ' class="' + (el.className||'').substring(0, 60) + '">');
    }
  });
  if (shadowCount === 0) results.push('无');

  // 输出到页面
  const div = document.createElement('div');
  div.id = 'jh-debug-output';
  div.style.cssText = 'position:fixed;top:0;left:0;width:600px;max-height:500px;overflow:auto;z-index:99999;background:#fff;border:2px solid red;padding:10px;font-size:11px;white-space:pre-wrap;font-family:monospace;';
  div.textContent = results.join('\n');
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '关闭';
  closeBtn.style.cssText = 'position:absolute;top:5px;right:5px;font-size:14px;padding:2px 8px;cursor:pointer;';
  closeBtn.onclick = () => div.remove();
  div.appendChild(closeBtn);
  document.body.appendChild(div);
})();